
import numpy as np
import matplotlib.pyplot as plt

def generate_universes(n=10000):
    return [np.random.randint(0, 2, size=np.random.randint(50, 200)) for _ in range(n)]

def emergence_score(universe):
    return np.mean(universe) * (1 - np.std(universe))  # placeholder

def compressibility_score(universe):
    import gzip
    import io
    byte_string = bytes(universe)
    compressed = gzip.compress(byte_string)
    return len(compressed) / len(byte_string)

def run_simulation():
    universes = generate_universes()
    emergence = []
    compression = []
    for u in universes:
        emergence.append(emergence_score(u))
        compression.append(compressibility_score(u))
    return np.array(emergence), np.array(compression)

def plot_heatmap(e, c):
    plt.hexbin(e, c, gridsize=50, cmap='inferno')
    plt.xlabel("Emergence Score")
    plt.ylabel("Compression Ratio")
    plt.colorbar(label="Density")
    plt.savefig("emergence_entropy_heatmap.png")

if __name__ == "__main__":
    e, c = run_simulation()
    plot_heatmap(e, c)
