
# Betsyon Detection Strategy (Collider Reinterpretation Memo)

## Objective
To identify signals of a scalar field (Betsyon) responsible for CP-violating baryogenesis, consistent with the proposed phase transition model.

## Method
1. Reinterpret existing ATLAS/CMS 13 TeV data using scalar mediator models.
2. Focus on final states with displaced vertices, lepton jets, or enhanced CP-violating decays.
3. Benchmark with models at ~10–200 GeV mass scale with weak scalar couplings.

## Observable Signature
- Deviations in CP asymmetries
- Soft displaced scalar decays
- Higgs portal couplings at small mixing angles

## Recommended Tools
- MadGraph + Pythia + Delphes for MC generation
- Rivet or CheckMATE for data reinterpretation
