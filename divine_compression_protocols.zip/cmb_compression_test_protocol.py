
import gzip
import numpy as np

def compress_and_get_ratio(filename):
    with open(filename, 'rb') as f:
        data = f.read()
    original_size = len(data)
    compressed_data = gzip.compress(data)
    compressed_size = len(compressed_data)
    return compressed_size / original_size

def compare_cmb_to_mock(cmb_files, mock_files):
    results = []
    for cmb, mock in zip(cmb_files, mock_files):
        cmb_ratio = compress_and_get_ratio(cmb)
        mock_ratio = compress_and_get_ratio(mock)
        advantage = mock_ratio - cmb_ratio
        results.append((cmb, cmb_ratio, mock_ratio, advantage))
    return results

# Example filenames (update with actual paths)
cmb_files = ['cmb1.fits', 'cmb2.fits']
mock_files = ['mock1.fits', 'mock2.fits']

if __name__ == "__main__":
    res = compare_cmb_to_mock(cmb_files, mock_files)
    for r in res:
        print(f"{r[0]}: CMB Ratio={r[1]:.5f}, Mock Ratio={r[2]:.5f}, Advantage={r[3]:.5f}")
