
import gzip
import random

def load_dna_sequence(file_path):
    with open(file_path, 'r') as f:
        return ''.join(line.strip() for line in f if not line.startswith('>'))

def shuffle_sequence(seq):
    s = list(seq)
    random.shuffle(s)
    return ''.join(s)

def compress_ratio(seq):
    original = seq.encode()
    compressed = gzip.compress(original)
    return len(compressed) / len(original)

def compare_dna(file_path):
    real = load_dna_sequence(file_path)
    shuffled = shuffle_sequence(real)
    real_ratio = compress_ratio(real)
    shuffled_ratio = compress_ratio(shuffled)
    return real_ratio, shuffled_ratio, shuffled_ratio - real_ratio

if __name__ == "__main__":
    real, shuffled, advantage = compare_dna("example_dna.fa")
    print(f"Real Ratio: {real:.5f}, Shuffled Ratio: {shuffled:.5f}, Advantage: {advantage:.5f}")
