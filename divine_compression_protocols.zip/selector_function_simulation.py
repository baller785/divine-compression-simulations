
import numpy as np
import matplotlib.pyplot as plt

def simulate_selector(n=10000):
    complexity = np.random.normal(250, 50, size=n)
    entropy = np.random.normal(2.5, 0.5, size=n)
    emergence_score = np.exp(-complexity/200) * np.exp(-((entropy - 2.5)**2)/4)
    return complexity, entropy, emergence_score

def plot_selector_output(c, e, s):
    plt.figure(figsize=(8,6))
    plt.scatter(c, s, c=e, cmap='plasma', alpha=0.6)
    plt.xlabel("Complexity")
    plt.ylabel("Emergence Score")
    plt.colorbar(label="Entropy")
    plt.title("Selector Function Output")
    plt.savefig("selector_function_output.png")

if __name__ == "__main__":
    c, e, s = simulate_selector()
    plot_selector_output(c, e, s)
